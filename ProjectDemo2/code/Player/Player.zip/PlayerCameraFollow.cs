﻿using UnityEngine;
using System.Collections;

public class PlayerCameraFollow : MonoBehaviour {

    public GameObject player;       //Public variable to store a reference to the player game object
    private Vector3 offset;         //Private variable to store the offset distance between the player and camera

                                    // Use this for initialization
    void Start () {
        offset = transform.position - player.transform.position;//为了让视角跟随玩家，计算偏移向量

    }

    // Update is called once per frame
    void LateUpdate()
    {
        // Set the position of the camera's transform to be the same as the player's, but offset by the calculated offset distance.
        transform.position = player.transform.position + offset;
        //这里并不是直接让视角 = 玩家的位置，而是加上了偏移值，是为了做到视摄像机延迟跟随的效果（更平滑）
    }
}
